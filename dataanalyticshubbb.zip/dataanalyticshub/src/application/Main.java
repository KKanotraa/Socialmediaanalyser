package application;

public class Main {

    public static void main(String[] args) {
        SocialMediaAnalyzerGUI.launch(SocialMediaAnalyzerGUI.class, args);
    }
}
