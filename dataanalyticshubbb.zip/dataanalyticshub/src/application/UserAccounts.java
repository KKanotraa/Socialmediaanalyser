package application;

import java.io.*;
import java.util.HashMap;

/**
 * Class to manage user accounts and authentication
 */
public class UserAccounts {
    private HashMap<String, String> users;
    private final String userDataFile = "users.dat";

    public UserAccounts() {
        this.users = new HashMap<>();
        loadUserData();
    }

    private void loadUserData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(userDataFile))) {
            users = (HashMap<String, String>) ois.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("User data file not found. Creating a new one.");
            users = new HashMap<>();
            saveUserData(); // Save a new user data file
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void saveUserData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(userDataFile))) {
            oos.writeObject(users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean isValidUser(String username, String password) {
        String storedPassword = users.get(username);
        return storedPassword != null && storedPassword.equals(password);
    }

    public void addUser(String username, String password) {
        users.put(username, password);
        saveUserData();
    }

    public HashMap<String, String> getUsers() {
        return users;
    }
}
