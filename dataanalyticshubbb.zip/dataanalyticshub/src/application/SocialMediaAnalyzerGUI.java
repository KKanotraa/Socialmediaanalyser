package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class SocialMediaAnalyzerGUI extends Application {
    private Button loadButton;
    private Button addButton;
    private Button deleteButton;
    private Button viewButton;
    private Button vipButton;
    private Button topLikesButton;
    private HBox buttonBox;
    private TextArea textArea;

    private UserAccounts userAccounts;
    private User currentUser;
    private Stage primaryStage;
    private Records records;
    private SocialMediaAnalyser analyser;

    private Scene loginScene;

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Social Media Analyzer");

        // Initialize user accounts
        userAccounts = new UserAccounts();
        analyser = new SocialMediaAnalyser(); // Initialize SocialMediaAnalyser
        records = new Records(); // Initialize Records

        // Create login scene
        BorderPane loginPane = createLoginPane();
        loginScene = new Scene(loginPane, 400, 300);

        // Show login scene
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    private BorderPane createLoginPane() {
        BorderPane pane = new BorderPane();

        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> handleLogin(usernameField.getText(), passwordField.getText()));

        Button registerButton = new Button("Register");
        registerButton.setOnAction(e -> handleRegister(usernameField.getText(), passwordField.getText()));

        vbox.getChildren().addAll(usernameField, passwordField, loginButton, registerButton);

        pane.setCenter(vbox);
        return pane;
    }

    private void handleLogin(String username, String password) {
        if (userAccounts.isValidUser(username, password)) {
            User user = new User(username, password); // Create a User object
            setCurrentUser(user); // Set the current user
            primaryStage.setScene(createMainScene());
        } else {
            showAlert("Invalid username or password. Please try again.", Alert.AlertType.ERROR);
        }
    }

    private void handleRegister(String username, String password) {
        if (!username.isEmpty() && !password.isEmpty()) {
            userAccounts.addUser(username, password);
            showAlert("User registered successfully!", Alert.AlertType.INFORMATION);
        } else {
            showAlert("Both username and password are required.", Alert.AlertType.ERROR);
        }
    }

    private Scene createMainScene() {
        // Buttons
        loadButton = createStyledButton("Load Posts", Color.MAGENTA);
        addButton = createStyledButton("Add Post", Color.YELLOW);
        deleteButton = createStyledButton("Delete Post", Color.RED);
        viewButton = createStyledButton("View Post", Color.PINK);
        vipButton = createStyledButton("VIP Subscription", Color.GREEN);
        topLikesButton = createStyledButton("Top Liked Posts", Color.BLUE);
        buttonBox = new HBox(10, loadButton, addButton, deleteButton, viewButton, vipButton);


        // Text area
        textArea = createStyledTextArea();

        // Button actions
        
        topLikesButton.setOnAction(e -> {
            if (currentUser != null) {
                retrieveTopLikedPosts();
            } else {
                showAlert("Please log in first!", Alert.AlertType.WARNING);
            }
        });

        buttonBox.getChildren().add(topLikesButton);
        
        
        loadButton.setOnAction(e -> {
            if (currentUser != null) {
                loadPosts();
            } else {
                showAlert("Please log in first!", Alert.AlertType.WARNING);
            }
        });

        addButton.setOnAction(e -> {
            if (currentUser != null) {
                addPost();
            } else {
                showAlert("Please log in first!", Alert.AlertType.WARNING);
            }
        });

        deleteButton.setOnAction(e -> {
            if (currentUser != null) {
                deletePost();
            } else {
                showAlert("Please log in first!", Alert.AlertType.WARNING);
            }
        });

        viewButton.setOnAction(e -> {
            if (currentUser != null) {
                viewPost();
            } else {
                showAlert("Please log in first!", Alert.AlertType.WARNING);
            }
        });

        vipButton.setOnAction(e -> {
            if (currentUser != null) {
                activateVIPSubscription();
            } else {
                showAlert("Please log in first!", Alert.AlertType.WARNING);
            }
        });

        // Layout
        
        buttonBox.getChildren().addAll(loadButton, addButton, deleteButton, viewButton, vipButton, topLikesButton);
        textArea = createStyledTextArea();


        HBox buttonBox = new HBox(10, loadButton, addButton, deleteButton, viewButton, vipButton, topLikesButton);
        VBox vbox = new VBox(10, buttonBox, textArea);
        vbox.setPadding(new Insets(10));

        return new Scene(vbox, 800, 600);

    }

    private Button createStyledButton(String label, Color color) {
        Button button = new Button(label);
        button.setStyle("-fx-background-color: #" + color.toString().substring(2));
        button.setTextFill(Color.BLACK);
        return button;
    }

    private TextArea createStyledTextArea() {
        TextArea textArea = new TextArea();
        textArea.setFont(new javafx.scene.text.Font("Arial", 14));
        textArea.setWrapText(true);
        return textArea;
    }
    
    private int getLimitFromUser() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Enter Limit");
        dialog.setHeaderText(null);
        dialog.setContentText("Please enter the limit:");

        Optional<String> result = dialog.showAndWait();

        if (result.isPresent()) {
            try {
                int limit = Integer.parseInt(result.get());
                if (limit > 0) {
                    return limit;
                } else {
                    showAlert("Limit must be a positive integer.", Alert.AlertType.ERROR);
                }
            } catch (NumberFormatException e) {
                showAlert("Invalid input. Please enter a valid integer.", Alert.AlertType.ERROR);
            }
        }

        return -1; // Default return value (you can choose a different default if needed)
    }

    
    
    private void retrieveTopLikedPosts() {
        int limit = getLimitFromUser(); // Implement getLimitFromUser method to get user input for N

        try {
            ArrayList<Post> topLikedPosts = records.getTopPosts("likes", limit);

            if (!topLikedPosts.isEmpty()) {
                displayTopLikedPosts(topLikedPosts);
            } else {
                textArea.appendText("No posts found.\n");
            }
        } catch (InvalidArgumentException ex) {
            showAlert(ex.getMessage(), Alert.AlertType.ERROR);
        }
    }
    
    private void displayTopLikedPosts(ArrayList<Post> topLikedPosts) {
        textArea.appendText("Top Liked Posts:\n\n");
        for (Post post : topLikedPosts) {
            String postInfo = String.format("ID: %d\nContent: %s\nAuthor: %s\nLikes: %d\nShares: %d\nDateTime: %s\n\n",
                    post.getID(), post.getContent(), post.getAuthor(), post.getLikes(),
                    post.getShares(), post.getDateTime());
            textArea.appendText(postInfo);
        }
    }

    private void loadPosts() {
        try {
            records.loadPostsFromCSV("posts.csv");
            displayLoadedPosts();
        } catch (FileNotFoundException e) {
            showAlert("Error loading posts: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void displayLoadedPosts() {
        textArea.clear(); // Clear the text area before displaying loaded posts
        HashMap<Integer, Post> posts = records.getPosts();
        for (Post post : posts.values()) {
            String postInfo = String.format("ID: %d\nContent: %s\nAuthor: %s\nLikes: %d\nShares: %d\nDateTime: %s\n\n",
                    post.getID(), post.getContent(), post.getAuthor(), post.getLikes(),
                    post.getShares(), post.getDateTime());
            textArea.appendText(postInfo);
        }
    }
    
    

    private void addPost() {
        try {
            int id = getValidPostID();
            String content = getValidContent();
            String author = getValidAuthor();
            int likes = getValidLikes();
            int shares = getValidShares();
            String dateTime = getValidDateTime();

            if (id != -1 && content != null && author != null && likes != -1 && shares != -1 && dateTime != null) {
                String result = addPostToDataStructure(id, content, author, likes, shares, dateTime);

                if (result != null) {
                    textArea.appendText(result + "\n\n");
                }
            }
        } catch (Exception e) {
            showAlert("An error occurred while adding the post: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private int getValidPostID() {
        while (true) {
            try {
                TextInputDialog dialog = new TextInputDialog();
                dialog.setTitle("Enter Post ID");
                dialog.setHeaderText(null);
                dialog.setContentText("Please provide the post ID:");

                Optional<String> result = dialog.showAndWait();

                if (result.isPresent()) {
                    int id = Integer.parseInt(result.get());
                    if (id >= 0) {
                        return id;
                    } else {
                        showAlert("Post ID must be a non-negative integer.", Alert.AlertType.ERROR);
                    }
                } else {
                    return -1; // User canceled input
                }
            } catch (NumberFormatException e) {
                showAlert("Invalid input. Please enter a valid integer.", Alert.AlertType.ERROR);
            }
        }
    }

    private String getValidContent() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Enter Post Content");
        dialog.setHeaderText(null);
        dialog.setContentText("Please provide the post content:");

        Optional<String> result = dialog.showAndWait();

        return result.orElse(null);
    }

    private String getValidAuthor() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Enter Post Author");
        dialog.setHeaderText(null);
        dialog.setContentText("Please provide the post author:");

        Optional<String> result = dialog.showAndWait();

        return result.orElse(null);
    }

    private int getValidLikes() {
        while (true) {
            try {
                TextInputDialog dialog = new TextInputDialog();
                dialog.setTitle("Enter Number of Likes");
                dialog.setHeaderText(null);
                dialog.setContentText("Please provide the number of likes of the post:");

                Optional<String> result = dialog.showAndWait();

                if (result.isPresent()) {
                    int likes = Integer.parseInt(result.get());
                    if (likes >= 0) {
                        return likes;
                    } else {
                        showAlert("Likes must be a non-negative integer.", Alert.AlertType.ERROR);
                    }
                } else {
                    return -1; // User canceled input
                }
            } catch (NumberFormatException e) {
                showAlert("Invalid input. Please enter a valid integer.", Alert.AlertType.ERROR);
            }
        }
    }

    private int getValidShares() {
        while (true) {
            try {
                TextInputDialog dialog = new TextInputDialog();
                dialog.setTitle("Enter Number of Shares");
                dialog.setHeaderText(null);
                dialog.setContentText("Please provide the number of shares of the post:");

                Optional<String> result = dialog.showAndWait();

                if (result.isPresent()) {
                    int shares = Integer.parseInt(result.get());
                    if (shares >= 0) {
                        return shares;
                    } else {
                        showAlert("Shares must be a non-negative integer.", Alert.AlertType.ERROR);
                    }
                } else {
                    return -1; // User canceled input
                }
            } catch (NumberFormatException e) {
                showAlert("Invalid input. Please enter a valid integer.", Alert.AlertType.ERROR);
            }
        }
    }

    private String getValidDateTime() {
        while (true) {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Enter Date and Time");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter the date and time in the format DD/MM/YYYY HH:MM:");

            Optional<String> result = dialog.showAndWait();

            if (result.isPresent()) {
                String dateTime = result.get();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                dateFormat.setLenient(false); // This makes the date validation strict

                try {
                    // Try parsing the date and time
                    Date parsedDate = dateFormat.parse(dateTime);

                    // Ensure the parsed date matches the original string (no partial matching)
                    if (dateTime.equals(dateFormat.format(parsedDate))) {
                        return dateTime;
                    } else {
                        showAlert("Invalid date and time format. Please enter in DD/MM/YYYY HH:MM format.", Alert.AlertType.ERROR);
                    }
                } catch (ParseException e) {
                    showAlert("Invalid date and time format. Please enter in DD/MM/YYYY HH:MM format.", Alert.AlertType.ERROR);
                }
            } else {
                // User canceled the input, you can handle it as needed
                return null;
            }
        }
    }



    private String addPostToDataStructure(int id, String content, String author, int likes, int shares, String dateTime) {
        try {
            records.addPost(id, content, author, likes, shares, dateTime);
            records.savePostsToCSV("posts.csv"); // Save posts to CSV with the filename "posts.csv"
            return "Post added successfully!";
        } catch (InvalidIDException e) {
            return "Invalid ID: " + e.getMessage();
        } catch (ParseValueException e) {
            return "Parse error: " + e.getMessage();
        } catch (IOException e) {
            return "IO error: " + e.getMessage();
        }
    }
    
    private void displayPosts() {
        textArea.clear(); // Clear the text area before displaying posts
        HashMap<Integer, Post> posts = records.getPosts();
        for (Post post : posts.values()) {
            String postInfo = String.format("ID: %d\nContent: %s\nAuthor: %s\nLikes: %d\nShares: %d\nDateTime: %s\n\n",
                    post.getID(), post.getContent(), post.getAuthor(), post.getLikes(),
                    post.getShares(), post.getDateTime());
            textArea.appendText(postInfo);
        }
    }






    private void deletePost() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Delete Post");
        dialog.setHeaderText(null);
        dialog.setContentText("Please provide the post ID:");

        Optional<String> result = dialog.showAndWait();

        if (result.isPresent()) {
            try {
                int postID = Integer.parseInt(result.get());
                boolean deleted = records.deletePostByID(postID);
                if (deleted) {
                    showAlert("Post deleted successfully.", Alert.AlertType.INFORMATION);
                    displayPosts(); // Update the GUI to reflect the deleted post
                } else {
                    showAlert("Post with ID " + postID + " not found.", Alert.AlertType.ERROR);
                }
            } catch (NumberFormatException e) {
                showAlert("Invalid input. Please enter a valid integer.", Alert.AlertType.ERROR);
            } catch (InvalidIDException e) {
                showAlert("Error deleting post: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

   

    private void viewPost() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("View Post");
        dialog.setHeaderText(null);
        dialog.setContentText("Enter ID of the post to view:");

        dialog.showAndWait().ifPresent(postId -> {
            try {
                int id = Integer.parseInt(postId);
                String postDetails = viewPostFromDataStructure(id);

                if (postDetails != null) {
                    textArea.appendText(postDetails + "\n\n");
                } else {
                    textArea.appendText("Post with ID " + id + " not found\n");
                }
            } catch (InvalidIDException e) {
                showAlert("Invalid ID. Please try again.", Alert.AlertType.ERROR);
            } catch (NumberFormatException e) {
                showAlert("Invalid input. Please enter a valid integer ID.", Alert.AlertType.ERROR);
            }
        });
    }

    private String viewPostFromDataStructure(int id) throws InvalidIDException {
        Post post = records.getPost(id);
        if (post != null) {
            return post.toString();
        }
        return null;
    }

    private void activateVIPSubscription() {
        if (currentUser != null) {
            // Simulate VIP subscription activation (this is a simplified example)
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("VIP Subscription");
            alert.setHeaderText(null);
            alert.setContentText("VIP Subscription for 1 year successfully activated!");
            alert.showAndWait();
        } else {
            showAlert("Please log in first!", Alert.AlertType.WARNING);
        }
    }

    private void showAlert(String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle("Information Dialog");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        // Launch the GUI
        launch(args);
    }
}
